import javax.swing.JFrame;


public class Test{

	public static void main(String[] args) {
		KitAssemblyManager k = new KitAssemblyManager();
		k.setSize(800,800);
		k.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		k.setVisible(true);
		//k.run();

	}

}
