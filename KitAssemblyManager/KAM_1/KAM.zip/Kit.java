public class Kit extends FactoryObject
{
	Part[] parts;
	public Kit(int xpos, int ypos, String image)
	{
		x = xpos;
		y = ypos;
		setImage(image);
		parts = new Part[8];
	}
	
	public Part[] getParts(){
		return parts;
	}

}